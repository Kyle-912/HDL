Group Members:
1. Shiva Jyothi Mallidi(UFID: 75384078)
2. Kyle Thompson(UFID: 30130224)


Shiva had reached out for a partner using slack while I had reached out using teams and neither of us recieved any responses till after we had seperately completed the assignment and I thought to checked the slack channel so we are now submitting as a team. He submitted for both of us on time last night and I verified his files also worked but since he had already submitted his work and just did a resubmission with my name appended to the top that hasn't really sat right with me since I understand the group idea was more with the intent that we work together so I've decided to also submit my work as proof that I did also complete the assignment but his is our group's official submission. My part1 files were renamed from lab2_part1 to match the format specified in the document but this may have broken some referrences.